# Bashlist :memo:

### Your Terminal To-Do manager

Setup your To-Do task directly from your terminal

### Requirements

> Python >= (3.6)

> Package Installer for Python(PIP) >= 22.3

# Installation

To install **Bashlist**, run:
```
pip install bashlist
```

# Usage

## Help

```
bashlist --help 
```

# Let's fucking goooo
- Author: Oluwaseun
